Release copy: first draft.
